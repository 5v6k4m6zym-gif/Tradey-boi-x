"""
Settings management for Tradey Boi Pro.
All config persisted in SQLite — user never edits code.
"""
from __future__ import annotations
from db.database import get_setting, set_setting, get_all_settings

DEFAULTS: dict = {
    # Connection
    "mode":                  "PAPER",      # PAPER | LIVE
    "ibkr_host":             "127.0.0.1",
    "ibkr_port":             4002,          # 4002=Gateway paper, 4001=Gateway live, 7497=TWS paper
    "ibkr_client_id":        1,
    "bot_enabled":           False,

    # Risk management
    "max_positions":         5,
    "risk_pct":              2.0,           # % of account per trade (STRONG BUY baseline)
    "risk_pct_elite":        3.0,           # % of account for ELITE signals (higher conviction = larger size)
    "regime_size_scale":     True,          # scale position size by market regime (1.2× BULL, 0.75× NEUTRAL)
    "max_daily_loss_pct":    3.0,
    "max_exposure_pct":      30.0,
    "brokerage":             2.0,           # $ per side

    # Exit parameters — pro-sweep winner: tight ATR stops + 15-day hold + early BE
    # Backtest result: PF=2.248, WR=80%, ROI=+6.4%, 54 trades, MaxDD=1.4%
    "hold_days":             15,
    # Stops widened so daily noise doesn't prematurely trigger them.
    # Targets now derived as 3× stop distance at trade entry (3:1 R:R always).
    # The target_hi/mid/lo keys are kept for dashboard display only — the engine
    # computes target_price = entry + 3 × stop_dist and ignores these values.
    "sl_mult_hi":            1.5,     # high-ATR (≥3% ATR): 4.5% stop on 3% ATR stock
    "sl_mult_mid":           1.2,     # mid-ATR (1.5-3%): 2.4% stop on 2% ATR stock
    "sl_mult_lo":            1.0,     # low-ATR (<1.5%): 1% stop on 1% ATR stock
    "target_hi":             10.0,    # display only — actual target = 3× stop dist
    "target_mid":            7.0,
    "target_lo":             5.0,

    # Dynamic stop management — pro-sweep winner: BE=0.5R, Trail=1.5R/0.7R
    "min_hold_days":         2,       # stop cannot trigger in first N days (entry-day noise)
    "be_trigger_r":          0.5,     # slide stop to entry at +0.5R — fast BE protection reduces avg loss
    "trail_trigger_r":       2.0,     # raised from 1.5 — don't trail until move is established
    "trail_dist_r":          1.0,     # widened from 0.7 — room to breathe on pullbacks

    # Signal quality gates — pro-sweep winner: score≥5, prob≥0.50
    # Lowered from 8/0.58: oversold-recovery signals (RSI 35-42, vol>1.5) score 5
    # and have heuristic prob 0.55-0.57 — previously excluded, now included
    "min_prob":              0.55,    # raised from 0.50 — require higher AI confidence
    "min_score":             7,       # raised from 6 — requires breakout OR high-prob setup
    "min_expected_r":        1.5,     # minimum EV in R units (gates low R:R setups)
    "min_composite":         7.5,     # live bot: composite_score threshold (ranker 0-10 scale)

    # Earnings guard — skip entries within N calendar days of a known earnings date.
    # Earnings can gap a stock ±15-30% overnight, bypassing the stop loss entirely.
    # 5 days gives a full trading week of protection. Set 0 to disable.
    "earnings_guard_days":   5,

    # Circuit breaker
    "cb_consecutive_losses": 3,
    "cb_pause_days":         7,

    # Scanner (Pro-specific — much more frequent than X)
    "scan_interval_mins":    15,            # scan every 15 min during market hours
    "enabled_markets":       ["ASX", "US"], # which markets to scan

    # X integration (optional secondary source)
    "signal_log_path":       "../tradey-boi-x/signal_log.json",
}


def get(key: str):
    val = get_setting(key)
    if val is None:
        return DEFAULTS.get(key)
    return val


def set(key: str, value):
    set_setting(key, value)


def all_settings() -> dict:
    stored = get_all_settings()
    return {**DEFAULTS, **stored}


def ensure_defaults():
    stored = get_all_settings()
    for key, val in DEFAULTS.items():
        if key not in stored:
            set_setting(key, val)


# Keys that must be force-updated on every startup to apply tuning improvements.
# ensure_defaults() only writes MISSING keys — existing DB values are untouched.
# Any key listed here gets overwritten unconditionally so users always run the
# latest optimised parameters without needing to manually reset their database.
_FORCED_UPDATES: dict = {
    "min_score":         7,      # v3: raised 5→6→7 (breakout OR prob≥0.70 required)
    "min_prob":          0.55,   # v3: raised 0.50→0.55
    "target_hi":         10.0,   # v3: lowered 15→10% (achievable in 15-day hold)
    "target_mid":        7.0,    # v3: lowered 10→7%
    "target_lo":         5.0,    # v3: lowered 7→5%
    "trail_trigger_r":   2.0,    # v3: raised 1.5→2.0 (don't trail prematurely)
    "trail_dist_r":      1.0,    # v3: widened 0.7→1.0 (room to breathe on pullbacks)
    "sl_mult_hi":        1.5,    # v4: widened — outside daily noise range
    "sl_mult_mid":       1.2,
    "sl_mult_lo":        1.0,
    "be_trigger_r":      0.5,    # v2: fast BE protection
    "hold_days":         15,
}


def migrate_settings():
    """Force-write all tuned parameters regardless of what is currently in the DB."""
    for key, val in _FORCED_UPDATES.items():
        set_setting(key, val)
